<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Online Exam Preparation Portal</title>
</head>
<body>
<h1>Welcome to the Online Exam Preparation Portal</h1>
</body>
</html>
